package id.nprinter.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/** Menerima perintah cetak dari web (nprinter:/rawbt:) atau Share teks, lalu mencetak. */
public class PrintActivity extends Activity {

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setFinishOnTouchOutside(false);

        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(24), dp(20), dp(24), dp(20));
        box.addView(new ProgressBar(this));
        TextView t = new TextView(this);
        t.setText("Mencetak...");
        t.setTextSize(16);
        t.setPadding(dp(16), dp(10), 0, 0);
        box.addView(t);
        setContentView(box);

        final byte[] data;
        try {
            data = parse(getIntent());
        } catch (Exception e) {
            done("Data cetak tidak valid: " + e.getMessage());
            return;
        }
        if (data == null || data.length == 0) { done("Tidak ada data untuk dicetak"); return; }

        if (!Printer.hasPermission(this) || !Printer.hasPrinter(this)) {
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra("msg", "Atur printer & izin Bluetooth dulu, lalu cetak ulang dari web.");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
            return;
        }

        Printer.QUEUE.execute(new Runnable() {
            @Override public void run() {
                String msg;
                try { Printer.print(getApplicationContext(), data); msg = "Berhasil dicetak"; }
                catch (Exception e) { msg = e.getMessage(); }
                final String m = msg;
                runOnUiThread(new Runnable() { @Override public void run() { done(m); } });
            }
        });
    }

    private byte[] parse(Intent in) {
        if (Intent.ACTION_SEND.equals(in.getAction())) {
            String text = in.getStringExtra(Intent.EXTRA_TEXT);
            return text == null ? null : Printer.textToEsc(text);
        }
        Uri u = in.getData();
        if (u == null) return null;
        String s = Uri.decode(u.getEncodedSchemeSpecificPart());
        if (s == null) return null;
        while (s.startsWith("/")) s = s.substring(1);
        if (s.startsWith("base64,")) {
            return Base64.decode(s.substring(7).trim(), Base64.DEFAULT);
        }
        if (s.startsWith("text,")) s = s.substring(5);
        return Printer.textToEsc(s);
    }

    private void done(String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
        finish();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
