package id.nprinter.app;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Kirim data ESC/POS mentah ke printer thermal Bluetooth (SPP). */
public final class Printer {
    static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    static final String PREF = "printer", KEY_ADDR = "addr", KEY_NAME = "name", KEY_COLS = "cols";
    static final String PERM_CONNECT = "android.permission.BLUETOOTH_CONNECT";

    /** Antrian tunggal supaya cetakan tidak tabrakan. */
    static final ExecutorService QUEUE = Executors.newSingleThreadExecutor();

    private Printer() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    static boolean hasPermission(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        return c.checkSelfPermission(PERM_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean hasPrinter(Context c) {
        return prefs(c).getString(KEY_ADDR, null) != null;
    }

    static String printerLabel(Context c) {
        SharedPreferences p = prefs(c);
        String a = p.getString(KEY_ADDR, null);
        if (a == null) return "Belum ada printer dipilih";
        return p.getString(KEY_NAME, "Printer") + "\n" + a;
    }

    /** Blocking: panggil dari background thread. */
    static void print(Context c, byte[] data) throws Exception {
        if (!hasPermission(c)) throw new Exception("Izin Bluetooth belum diberikan. Buka aplikasi N Printer.");
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null) throw new Exception("Perangkat ini tidak punya Bluetooth");
        if (!ad.isEnabled()) throw new Exception("Bluetooth belum aktif");
        String addr = prefs(c).getString(KEY_ADDR, null);
        if (addr == null) throw new Exception("Printer belum dipilih. Buka aplikasi N Printer.");

        BluetoothDevice dev = ad.getRemoteDevice(addr);
        try { ad.cancelDiscovery(); } catch (Exception ignored) {}

        BluetoothSocket s = connect(dev);
        try {
            OutputStream os = s.getOutputStream();
            int off = 0;
            while (off < data.length) {
                int n = Math.min(512, data.length - off);
                os.write(data, off, n);
                os.flush();
                off += n;
                Thread.sleep(15);
            }
            Thread.sleep(800); // beri waktu buffer printer terkirim sebelum socket ditutup
        } finally {
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    private static BluetoothSocket connect(BluetoothDevice dev) throws Exception {
        Exception last = null;
        for (int i = 0; i < 3; i++) {
            BluetoothSocket s = null;
            try {
                if (i == 0) s = dev.createRfcommSocketToServiceRecord(SPP);
                else if (i == 1) s = dev.createInsecureRfcommSocketToServiceRecord(SPP);
                else s = (BluetoothSocket) dev.getClass()
                        .getMethod("createRfcommSocket", int.class).invoke(dev, 1);
                s.connect();
                return s;
            } catch (Exception e) {
                last = e;
                if (s != null) try { s.close(); } catch (IOException ignored) {}
            }
        }
        throw new Exception("Gagal terhubung ke printer. Pastikan printer menyala & tidak dipakai perangkat lain."
                + (last != null && last.getMessage() != null ? "\n(" + last.getMessage() + ")" : ""));
    }

    /* ===== ESC/POS helper ===== */

    static void ascii(ByteArrayOutputStream b, String s) {
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            b.write(ch == '\n' ? 0x0A : (ch >= 32 && ch < 127) ? ch : '?');
        }
    }

    static byte[] textToEsc(String text) {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        b.write(0x1B); b.write(0x40);          // init
        ascii(b, text.replace("\r", ""));
        b.write(0x0A);
        b.write(0x1B); b.write(0x64); b.write(3); // feed 3
        return b.toByteArray();
    }

    static byte[] testPage(Context c, int cols) {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        String dash = repeat('-', cols);
        String now = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US).format(new Date());
        String name = prefs(c).getString(KEY_NAME, "Printer");

        b.write(0x1B); b.write(0x40);
        b.write(0x1B); b.write(0x61); b.write(1);           // center
        b.write(0x1D); b.write(0x21); b.write(0x11);        // 2x
        ascii(b, "N PRINTER\n");
        b.write(0x1D); b.write(0x21); b.write(0x00);
        ascii(b, "Test cetak berhasil\n" + now + "\n");
        b.write(0x1B); b.write(0x61); b.write(0);           // left
        ascii(b, dash + "\n");
        ascii(b, "Printer : " + name + "\n");
        ascii(b, "Lebar   : " + cols + " kolom\n");
        ascii(b, dash + "\n");
        b.write(0x1B); b.write(0x45); b.write(1);
        ascii(b, "Teks tebal\n");
        b.write(0x1B); b.write(0x45); b.write(0);
        StringBuilder ruler = new StringBuilder();
        while (ruler.length() < cols) ruler.append("0123456789");
        ascii(b, ruler.substring(0, cols) + "\n");
        b.write(0x1B); b.write(0x64); b.write(3);
        b.write(0x1D); b.write(0x56); b.write(0x41); b.write(0x03); // cut
        return b.toByteArray();
    }

    static String repeat(char ch, int n) {
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) sb.append(ch);
        return sb.toString();
    }
}
