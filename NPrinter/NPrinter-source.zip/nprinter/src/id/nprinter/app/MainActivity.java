package id.nprinter.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_PERM = 1, REQ_ENABLE = 2;
    private TextView status;
    private RadioGroup width;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("N Printer");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(20);
        root.setPadding(p, p, p, p);

        TextView h = new TextView(this);
        h.setText("Printer Thermal Bluetooth");
        h.setTextSize(20);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(h);

        TextView lbl = small("Printer aktif");
        lbl.setPadding(0, dp(16), 0, dp(4));
        root.addView(lbl);

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(dp(14), dp(12), dp(14), dp(12));
        status.setBackgroundColor(Color.parseColor("#E6F4F1"));
        status.setTextColor(Color.parseColor("#134E4A"));
        root.addView(status);

        Button pick = button("Pilih Printer Bluetooth");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { choosePrinter(); }
        });
        root.addView(pick);

        TextView wl = small("Lebar kertas (untuk test print)");
        wl.setPadding(0, dp(16), 0, 0);
        root.addView(wl);
        width = new RadioGroup(this);
        width.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton r58 = new RadioButton(this); r58.setText("58 mm"); r58.setId(32);
        RadioButton r80 = new RadioButton(this); r80.setText("80 mm"); r80.setId(48);
        width.addView(r58); width.addView(r80);
        width.check(Printer.prefs(this).getInt(Printer.KEY_COLS, 32));
        width.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int id) {
                Printer.prefs(MainActivity.this).edit().putInt(Printer.KEY_COLS, id).apply();
            }
        });
        root.addView(width);

        Button test = button("Test Print");
        test.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { testPrint(); }
        });
        root.addView(test);

        TextView info = small(
                "Cara cetak dari web:\n\n" +
                "intent:base64,<DATA>#Intent;scheme=nprinter;package=id.nprinter.app;end;\n\n" +
                "Format rawbt:base64,<DATA> juga didukung, jadi kode web untuk RawBT tetap jalan.\n\n" +
                "Bisa juga lewat menu Share > N Printer dari aplikasi lain untuk mencetak teks.");
        info.setTextIsSelectable(true);
        info.setPadding(0, dp(24), 0, 0);
        root.addView(info);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);

        // ===== Footer kredit (selalu di bawah layar) =====
        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setGravity(Gravity.CENTER_HORIZONTAL);
        footer.setPadding(dp(16), dp(10), dp(16), dp(12));
        footer.setBackgroundColor(Color.parseColor("#F3F4F6"));

        TextView by = new TextView(this);
        by.setText("Aplikasi dibuat oleh PusatJokian");
        by.setTextSize(13);
        by.setTypeface(Typeface.DEFAULT_BOLD);
        by.setTextColor(Color.parseColor("#374151"));
        by.setGravity(Gravity.CENTER);
        footer.addView(by);

        LinearLayout wa = new LinearLayout(this);
        wa.setGravity(Gravity.CENTER);
        TextView waLbl = new TextView(this);
        waLbl.setText("WA: ");
        waLbl.setTextSize(13);
        waLbl.setTextColor(Color.parseColor("#374151"));
        wa.addView(waLbl);
        wa.addView(waLink("+62 853-7863-0743", "6285378630743"));
        TextView sep = new TextView(this);
        sep.setText(" / ");
        sep.setTextColor(Color.parseColor("#6B7280"));
        wa.addView(sep);
        wa.addView(waLink("+62 851-7424-1454", "6285174241454"));
        footer.addView(wa);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        page.addView(footer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(page);

        String msg = getIntent().getStringExtra("msg");
        if (msg != null) Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        refresh();
        ensurePermission();
    }

    private void refresh() { status.setText(Printer.printerLabel(this)); }

    private boolean ensurePermission() {
        if (Printer.hasPermission(this)) return true;
        if (Build.VERSION.SDK_INT >= 23)
            requestPermissions(new String[]{Printer.PERM_CONNECT}, REQ_PERM);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_PERM && !Printer.hasPermission(this))
            Toast.makeText(this, "Izin Bluetooth diperlukan untuk mencetak", Toast.LENGTH_LONG).show();
    }

    private void choosePrinter() {
        if (!ensurePermission()) return;
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null) { toast("Perangkat ini tidak punya Bluetooth"); return; }
        if (!ad.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE);
            return;
        }
        final List<BluetoothDevice> list = new ArrayList<BluetoothDevice>(ad.getBondedDevices());
        if (list.isEmpty()) {
            new AlertDialog.Builder(this)
                    .setTitle("Belum ada perangkat")
                    .setMessage("Pairing printer dulu di Pengaturan > Bluetooth (PIN biasanya 0000 atau 1234), lalu kembali ke sini.")
                    .setPositiveButton("Buka Pengaturan", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));
                        }
                    })
                    .setNegativeButton("Tutup", null).show();
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            BluetoothDevice d = list.get(i);
            names[i] = (d.getName() != null ? d.getName() : "(tanpa nama)") + "\n" + d.getAddress();
        }
        new AlertDialog.Builder(this)
                .setTitle("Pilih printer")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dlg, int i) {
                        BluetoothDevice d = list.get(i);
                        Printer.prefs(MainActivity.this).edit()
                                .putString(Printer.KEY_ADDR, d.getAddress())
                                .putString(Printer.KEY_NAME, d.getName() != null ? d.getName() : "Printer")
                                .apply();
                        refresh();
                        toast("Printer disimpan");
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_ENABLE && res == RESULT_OK) choosePrinter();
    }

    private void testPrint() {
        if (!ensurePermission()) return;
        if (!Printer.hasPrinter(this)) { toast("Pilih printer dulu"); return; }
        final byte[] data = Printer.testPage(this, width.getCheckedRadioButtonId());
        toast("Mencetak...");
        Printer.QUEUE.execute(new Runnable() {
            @Override public void run() {
                String r;
                try { Printer.print(getApplicationContext(), data); r = "Test print terkirim"; }
                catch (Exception e) { r = e.getMessage(); }
                final String msg = r;
                runOnUiThread(new Runnable() { @Override public void run() { toast(msg); } });
            }
        });
    }

    private Button button(String t) {
        Button b = new Button(this);
        b.setText(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    /** Teks nomor WA yang bisa diklik untuk membuka chat WhatsApp. */
    private TextView waLink(String label, final String number) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(13);
        v.setTextColor(Color.parseColor("#0F766E"));
        v.setPaintFlags(v.getPaintFlags() | android.graphics.Paint.UNDERLINE_TEXT_FLAG);
        v.setPadding(0, dp(4), 0, dp(4));
        v.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View x) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://wa.me/" + number)));
                } catch (Exception e) { toast("WhatsApp tidak ditemukan"); }
            }
        });
        return v;
    }

    private TextView small(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(13);
        v.setTextColor(Color.parseColor("#6B7280"));
        v.setGravity(Gravity.START);
        return v;
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
