#!/bin/bash
# Build N Printer APK tanpa Gradle (butuh: aapt, javac, dalvik-exchange/dx, zipalign, apksigner)
set -e
cd "$(dirname "$0")"
ANDROID_JAR=${ANDROID_JAR:-/usr/lib/android-sdk/platforms/android-23/android.jar}
KS=${KS:-nprinter.jks}; KS_PASS=${KS_PASS:-nprinter123}
rm -rf build && mkdir -p build/gen build/classes
[ -f "$KS" ] || keytool -genkeypair -keystore "$KS" -storepass "$KS_PASS" -keypass "$KS_PASS" \
  -alias nprinter -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=N Printer, O=N Printer, C=ID"
aapt package -f -m -0 arsc -J build/gen -M AndroidManifest.xml -S res -I "$ANDROID_JAR" -F build/unsigned.apk
javac -nowarn -source 8 -target 8 -bootclasspath "$ANDROID_JAR" -d build/classes \
  $(find build/gen src -name '*.java') 2>&1 | grep -v "^warning" || true
dalvik-exchange --dex --output=build/classes.dex build/classes
(cd build && zip -q unsigned.apk classes.dex)
zipalign -f 4 build/unsigned.apk build/aligned.apk
apksigner sign --ks "$KS" --ks-pass pass:"$KS_PASS" --out NPrinter.apk build/aligned.apk
apksigner verify --print-certs NPrinter.apk | head -1
echo "OK -> NPrinter.apk"
